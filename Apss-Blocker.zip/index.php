<!DOCTYPE html>
<html>
<head>
  <title>Appblock</title>
  <style>
   @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
    #suksesMessage {
      color: red;
      font-weight: bold;
      animation: blink 1s infinite; /* Menggunakan animasi 'blink' selama 1 detik secara berulang */
    }
    
        body {
            background-color: #f0f2f5;
            font-family: Arial, sans-serif;
        }
        .pilihan {
            max-width: 400px;
            height: 598px;
            margin: 0 auto;
            background-color: #fff;
            border: 3px solid #00FFFF;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            
            margin-top: 100px;
        }
        .about{
            width: 90px;
            height: 40px;
           padding:11px;
            background-color: #00FFFF;
            color: #000;
            border: none;
            
            cursor: pointer;
            font-weight: bold;
            font-size: 15px;
        }
         .box2 {
            max-width: 400px;
            height: 200px;
            margin: 0 auto;
            background-color: #fff;
            border: 3px solid #00FFFF;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
          
         }
            
        .submit {
            width: 100%;
            height: 40px;
            padding: 10px;
            background-color: #00FFFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            font-size: 19px;
        }
        img {
            width: 90px; 
        }
             .rev {
            width: 300px; 
        }
        .submit{
            border-width: 1px;
            width: 58%; 
            height: 38px;
            color: black;
            border-radius: 7px;
            border-color : #696969;
            font-weight: bold;
            font-size: 13px;
        }
        .submit:hover {
            background-color: #00FFFF;
            opacity: 0.7; 
        
        }
        </style>
  
</head>
<body>
 
  <form id="appform" class="pilihan">
</script>
     
      
        <center><img src="https://malaskuji.000webhostapp.com/blocking/logo.png" alt="Description of the image"></center>
        
  
<center><p><span id="tanggalwaktu"></span></p></center>
      
<script>
var dt = new Date();
document.getElementById("tanggalwaktu").innerHTML = dt.toLocaleDateString();
</script>
      
       <center><div class="judul">Pilih Aplikasi / Hostname</div></center>
       <br>
    <label>
      <input type="checkbox" name="revolt[]" value="ff"> Free-Fire
    </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>
      <input type="checkbox" name="revolt[]" value="pubg"> Pubg
    </label>
    <br>
    <label>
      <input type="checkbox" name="revolt[]" value="yt"> Youtube
    </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>
      <input type="checkbox" name="revolt[]" value="ph"> Pornhub
    <br>
    <label>
      <input type="checkbox" name="revolt[]" value="ml"> Mobile-Legends
    </label>&nbsp;<label>
      <input type="checkbox" name="revolt[]" value="xnxx"> Xnxx.com
    <br>
    <label>
      <input type="checkbox" name="revolt[]" value="tiktok"> Tiktok
    </label>
    <br>
    <br>
    <center><input type="submit" class="submit" value="SAVE"></center>
    <br>
    <div class="box2">
    <br>
    <br>
 <center><img src="https://malaskuji.000webhostapp.com/blocking/rev.png" class="rev" alt="Description of the image"></center>
    <br>Please select the application or hostname that will be blocked. !!!
    <br>
    <center><div id="suksesMessage" style="display: none; color: red; font-weight: bold;">
    Sukses !!! Silahkan Restart OpenClash</center>
  
        
    </div>
    <br>
    <center>
        <a href="http://pajrul.my.id" style="text-decoration:none"  class="about" button>Tentang Saya</button></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://pajrul.my.id/blocking/update.html" style="text-decoration:none"  class="about" button>Update</button></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://speedtest.com" style="text-decoration:none"  class="about" button>SpeedTest</button></a>
        </center>
      
  </div>
  </form>
  

  <script>
    const dataMapping = {
      ff: "# FreeFire\n  - DOMAIN-KEYWORD,freefire\n  - DOMAIN-SUFFIX,garena.com\n  - DOMAIN-SUFFIX,avatargarenanow-a.akamaihd.net\n  - DOMAIN-SUFFIX,cdngarenanow-a.akamaihd.net\n  - DOMAIN-SUFFIX,dlmobilegarena-a.akamaihd.net\n  - DOMAIN-SUFFIX,garena.co.id\n  - DOMAIN-SUFFIX,garena.co.th\n  - DOMAIN-SUFFIX,garena.live\n  - DOMAIN-SUFFIX,garena.my\n  - DOMAIN-SUFFIX,garena.ph\n  - DOMAIN-SUFFIX,garena.sg\n  - DOMAIN-SUFFIX,garena.tv\n  - DOMAIN-SUFFIX,garena.tw\n  - DOMAIN-SUFFIX,garena.vn\n  - DOMAIN-SUFFIX,garenanow.com\n  - DOMAIN-SUFFIX,seagroup.com\n",
      yt: "# > YouTube\n  - DOMAIN-SUFFIX,m.youtube.com\n  - DOMAIN-SUFFIX,www.youtube.com\n  - DOMAIN-SUFFIX,i.ytimg.com\n  - DOMAIN-SUFFIX,yt3.ggpht.com\n  - DOMAIN-SUFFIX,youtube.com\n  - DOMAIN-SUFFIX,s.youtube.com\n  - DOMAIN-SUFFIX,rr4---sn-npoldn7y.googlevideo.com\n  - DOMAIN-SUFFIX,youtubei.googleapis.com\n  - DOMAIN-SUFFIX,redirector.googlevideo.com\n  - DOMAIN-SUFFIX,googlevideo.com\n  - DOMAIN-SUFFIX,youtube-ui.l.google.com\n  - DOMAIN-SUFFIX,ytstatic.l.google.com\n",
      ml: "# MOBILE LEGENDS\n  - DOMAIN-SUFFIX,www.mobilelegends.com\n  - DOMAIN-SUFFIX,applink.mobilelegends.com\n  - DOMAIN-SUFFIX,assistant.mobilelegends.com\n  - DOMAIN-SUFFIX,creatorcamp.mobilelegends.com\n  - DOMAIN-SUFFIX,dev-test-web.mobilelegends.com\n  - DOMAIN-SUFFIX,esports.mobilelegends.com\n  - DOMAIN-SUFFIX,ftp.mobilelegends.com\n  - DOMAIN-SUFFIX,game.mobilelegends.com\n  - DOMAIN-SUFFIX,lore.mobilelegends.com\n  - DOMAIN-SUFFIX,m.mobilelegends.com\n  - DOMAIN-SUFFIX,manage.mobilelegends.com\n  - DOMAIN-SUFFIX,moba.mobilelegends.com\n  - DOMAIN-SUFFIX,kh.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,my.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,mysg.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,mysg-s4.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,mysg-s5.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,mysg-s6.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,sg.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,www.sg.mpl.mobilelegends.com\n  - DOMAIN-SUFFIX,msc.mobilelegends.com\n  - DOMAIN-SUFFIX,mtacc.mobilelegends.com\n  - DOMAIN-SUFFIX,play.mobilelegends.com\n  - DOMAIN-SUFFIX,static.mobilelegends.com\n  - DOMAIN-SUFFIX,web.mobilelegends.com\n  - DOMAIN-SUFFIX,worlds.mobilelegends.com\n",
      tiktok: "# > TikTok\n USER-AGENT,TikTok*\n DOMAIN-SUFFIX,musical.ly\n DOMAIN-SUFFIX,tiktokv.com\n DOMAIN-SUFFIX,tiktokcdn.com\n DOMAIN-KEYWORD,-tiktokcdn-com\n"
    };

    document.getElementById('appform').onsubmit = function(event) {
      event.preventDefault(); // Mencegah form submit secara default

      // Ambil data dari checkbox yang dipilih
      const checkboxes = document.querySelectorAll('input[name="revolt[]"]:checked');
      const selectedOptions = Array.from(checkboxes).map(checkbox => dataMapping[checkbox.value]);

      // Gabungkan teks dari setiap pilihan yang dipilih
      const payload = selectedOptions.join('\n');

      // Kirim data ke server menggunakan XMLHttpRequest (AJAX)
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'execute.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
          // Tampilkan pesan sukses atau lakukan tindakan lain
          console.log('Data berhasil disimpan.');
           document.getElementById('suksesMessage').style.display = 'block';
           document.getElementById('errorMessage').style.display = 'none';
        }
      };
      xhr.send(`data=${encodeURIComponent(payload)}`);
    };
  </script>
</body>
</html>
