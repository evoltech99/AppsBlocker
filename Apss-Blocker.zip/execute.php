<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['data'])) {
    $selectedOptions = $_POST['data'];

    // Teks tetap (fixed text)
    $fixedText = "payload:
        ";

    // Gabungkan teks tetap dengan data yang dipilih dari form
    $result = $fixedText . "\n" . $selectedOptions;

    // Simpan hasil ke file data.txt
    $file = 'reject.yaml';
    file_put_contents($file, $result);
  }
}
?>
